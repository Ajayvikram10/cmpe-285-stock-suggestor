# stock_suggestor

How to run this project?
 
 * source virt/bin/activate
 * python app.py
 * Goto localhost:3000/
